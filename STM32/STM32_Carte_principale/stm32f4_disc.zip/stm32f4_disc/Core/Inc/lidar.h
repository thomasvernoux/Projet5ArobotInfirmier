


void lidar_get_info();
void tests_lidar();

void reset_lidar();

void lidar_reception();
void reception_octet_data();

void lidar_scan();


void demarrer_pwm_lidar();

void uart_lidar_recieve();


void lidar_fin_du_message_recu();





