













void reception_M0();

void setup_com_M0();
