#include "main.h"
#include "spi.h"



void test_spi();
void test_spi_inverse();

void spi_transmit();



void moteur1();
void moteur2();

void cmd_marche_arret();

void fct_vierge();
