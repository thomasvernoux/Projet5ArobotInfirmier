




enum MOTOR_STATE_SPEED {stop, v1, v2, v3};
extern enum MOTOR_STATE_SPEED motor_state_speed;




