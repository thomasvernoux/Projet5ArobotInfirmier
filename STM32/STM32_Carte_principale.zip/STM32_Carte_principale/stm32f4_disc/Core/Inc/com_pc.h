
int envoyer_message_pc ();
void recevoir_message_pc();
void recevoir_message_pc2();
void traiter_message_pc();


extern int pwm;


